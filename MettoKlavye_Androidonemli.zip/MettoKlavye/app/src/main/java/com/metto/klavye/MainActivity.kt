package com.metto.klavye

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var hid: HidController? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        immersive()
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1) else startHid()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, g: IntArray) {
        if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) startHid()
    }

    override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f); if (f) immersive() }

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    private fun startHid() {
        hid = HidController(this) { s ->
            runOnUiThread { web.evaluateJavascript("window.btStatus&&btStatus(" + JSONObject.quote(s) + ")", null) }
        }.also { it.start() }
    }

    private fun pick() {
        val h = hid ?: return
        val l = h.bonded()
        if (l.isEmpty()) {
            AlertDialog.Builder(this).setMessage("Eşleşmiş cihaz yok. Önce 'Tableti görünür yap' ile telefondan eşleştir.")
                .setPositiveButton("Tamam", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Cihaz seç")
            .setItems(l.map { it.name ?: it.address }.toTypedArray()) { _, i -> h.connect(l[i]) }.show()
    }

    inner class Bridge {
        @JavascriptInterface
        fun key(down: Int, usage: Int) { hid?.key(down == 1, usage) }

        @JavascriptInterface
        fun menu() {
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity).setTitle("Bluetooth")
                    .setItems(arrayOf(
                        "1) Tableti görünür yap (telefondan eşleştir)",
                        "2) Eşleşmiş cihaza bağlan",
                        "Bluetooth ayarları"
                    )) { _, i ->
                        when (i) {
                            0 -> startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                                .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300))
                            1 -> pick()
                            2 -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                        }
                    }.show()
            }
        }
    }
}
