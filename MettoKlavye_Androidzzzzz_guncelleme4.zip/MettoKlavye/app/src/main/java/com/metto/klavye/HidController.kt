package com.metto.klavye

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import java.util.concurrent.Executors

/** Tableti Bluetooth HID klavye olarak tanıtır ve tuş raporları gönderir. */
@SuppressLint("MissingPermission")
class HidController(private val ctx: Context, private val onState: (String) -> Unit) {
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var hid: BluetoothHidDevice? = null
    @Volatile private var host: BluetoothDevice? = null
    private val keys = ArrayList<Int>()
    private var mods = 0
    private val exec = Executors.newSingleThreadExecutor()

    /** false = yazı modu (her basış kısa bir dokunuş, tuş asla takılı kalmaz), true = oyun modu (basılı tut) */
    @Volatile var hold = false

    private val ht = HandlerThread("hid").also { it.start() }
    private val q = Handler(ht.looper)

    private val cb = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            onState(if (registered) "Hazır. Telefondan eşleştir ya da cihaza bağlan" else "Kayıt başarısız")
        }
        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                host = device
                onState("Bağlı: " + (device.name ?: device.address))
            } else if (state == BluetoothProfile.STATE_DISCONNECTED && host == device) {
                host = null
                q.post { keys.clear(); mods = 0 }
                onState("Bağlantı koptu")
            }
        }
    }

    fun start() {
        val a = adapter
        if (a == null || !a.isEnabled) { onState("Bluetooth kapalı"); return }
        a.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Metto Klavye", "Klavye", "Metto", BluetoothHidDevice.SUBCLASS1_KEYBOARD, DESC
                )
                if (!h.registerApp(sdp, null, null, exec, cb)) onState("Bu cihaz Bluetooth klavye modunu desteklemiyor")
            }
            override fun onServiceDisconnected(profile: Int) { hid = null }
        }, BluetoothProfile.HID_DEVICE)
    }

    fun bonded(): List<BluetoothDevice> = adapter?.bondedDevices?.toList() ?: emptyList()

    fun connect(d: BluetoothDevice) {
        onState("Bağlanıyor: " + (d.name ?: d.address))
        hid?.connect(d)
    }

    fun key(down: Boolean, usage: Int) { q.post { apply(down, usage) } }

    /** Sayfadan gelen basılı tutma tekrarı: yazı modunda her tekrar yeni bir dokunuş */
    fun repeat(usage: Int) { q.post { if (!hold && usage < 224) tap(usage) } }

    private fun apply(down: Boolean, usage: Int) {
        if (usage >= 224) {
            val bit = 1 shl (usage - 224)
            mods = if (down) mods or bit else mods and bit.inv()
            push(); guard(); return
        }
        if (hold) {
            keys.remove(usage)
            if (down) keys.add(usage)
            push(); guard(); return
        }
        if (down) tap(usage)   // yazı modunda bırakma bilgisi gerekmez
    }

    private fun tap(usage: Int) {
        keys.remove(usage); keys.add(usage); push()
        q.postDelayed({ keys.remove(usage); push() }, 35)
    }

    private fun guard() {
        if (keys.isEmpty() && mods == 0) q.postDelayed({ if (keys.isEmpty() && mods == 0) push() }, 30)
    }

    private fun push() {
        val h = host ?: return
        val r = ByteArray(8)
        r[0] = mods.toByte()
        for (i in 0 until minOf(6, keys.size)) r[2 + i] = keys[i].toByte()
        hid?.sendReport(h, 1, r)
    }

    companion object {
        private val DESC: ByteArray = intArrayOf(
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
            0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
            0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
            0xC0
        ).map { it.toByte() }.toByteArray()
    }
}
