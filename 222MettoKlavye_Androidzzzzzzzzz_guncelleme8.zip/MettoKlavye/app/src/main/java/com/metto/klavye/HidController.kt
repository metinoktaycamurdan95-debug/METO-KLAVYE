package com.metto.klavye

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import java.util.concurrent.Executors

/** Tableti Bluetooth HID klavye olarak tanıtır ve tuş raporları gönderir. */
@SuppressLint("MissingPermission")
class HidController(private val ctx: Context, private val onState: (String) -> Unit) {
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val prefs = ctx.getSharedPreferences("hid", Context.MODE_PRIVATE)
    private var hid: BluetoothHidDevice? = null
    @Volatile private var host: BluetoothDevice? = null
    @Volatile private var registered = false
    @Volatile private var stopped = false
    private val keys = ArrayList<Int>()
    private var mods = 0
    private val downAt = HashMap<Int, Long>()
    private val pend = HashMap<Int, Runnable>()
    private var tries = 0
    private val exec = Executors.newSingleThreadExecutor()

    /** false = yazı modu (her basış kısa bir dokunuş, tuş asla takılı kalmaz), true = oyun modu (basılı tut) */
    @Volatile var hold = false

    private val ht = HandlerThread("hid").also { it.start() }
    private val q = Handler(ht.looper)

    private val cb = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            this@HidController.registered = registered
            onState(if (registered) "Hazır. Telefondan eşleştir ya da cihaza bağlan" else "Kayıt başarısız")
            if (registered) { tries = 0; q.postDelayed({ autoConnect() }, 800) }
        }
        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                host = device
                prefs.edit().putString("last", device.address).apply()
                // Her bağlantıda temiz başla: eski basılı tuş durumu kalmasın
                q.post {
                    keys.clear(); mods = 0; downAt.clear()
                    pend.values.forEach { q.removeCallbacks(it) }; pend.clear()
                    push()
                }
                onState("Bağlı: " + (device.name ?: device.address))
            } else if (state == BluetoothProfile.STATE_DISCONNECTED && host == device) {
                host = null
                q.post {
                    keys.clear(); mods = 0; downAt.clear()
                    pend.values.forEach { q.removeCallbacks(it) }; pend.clear()
                }
                onState("Bağlantı koptu, yeniden deneniyor…")
                tries = 0
                q.postDelayed({ autoConnect() }, 2500)
            }
        }
    }

    /** Son bağlanılan cihaza otomatik bağlan (birkaç kez dener) */
    private fun autoConnect() {
        if (stopped || !registered || host != null) return
        val addr = prefs.getString("last", null) ?: return
        val d = bonded().firstOrNull { it.address == addr } ?: return
        if (tries++ >= 6) return
        hid?.connect(d)
        q.postDelayed({ autoConnect() }, 6000)
    }

    fun start() {
        val a = adapter
        if (a == null || !a.isEnabled) { onState("Bluetooth kapalı"); return }
        a.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Metto Klavye", "Klavye", "Metto", BluetoothHidDevice.SUBCLASS1_KEYBOARD, DESC
                )
                if (!h.registerApp(sdp, null, null, exec, cb)) onState("Bu cihaz Bluetooth klavye modunu desteklemiyor")
            }
            override fun onServiceDisconnected(profile: Int) { hid = null }
        }, BluetoothProfile.HID_DEVICE)
    }

    /** Uygulama kapanırken kaydı temizle, yoksa yeniden açınca çift kayıt olur */
    fun stop() {
        stopped = true
        try { hid?.unregisterApp() } catch (_: Exception) {}
        try { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid) } catch (_: Exception) {}
        q.removeCallbacksAndMessages(null)
        ht.quitSafely()
    }

    fun bonded(): List<BluetoothDevice> = adapter?.bondedDevices?.toList() ?: emptyList()

    fun connect(d: BluetoothDevice) {
        onState("Bağlanıyor: " + (d.name ?: d.address))
        hid?.connect(d)
    }

    fun key(down: Boolean, usage: Int) { q.post { apply(down, usage) } }

    /** Sayfadan gelen basılı tutma tekrarı: yazı modunda her tekrar yeni bir dokunuş */
    fun repeat(usage: Int) { q.post { if (!hold && usage < 224) tap(usage) } }

    private fun apply(down: Boolean, usage: Int) {
        val now = SystemClock.uptimeMillis()
        if (down) {
            if (usage < 224 && !hold) { tap(usage); return }
            // aynı tuşa çok hızlı tekrar basıldıysa önceki bırakmayı hemen bitir
            pend.remove(usage)?.let { q.removeCallbacks(it); release(usage) }
            downAt[usage] = now
            if (usage >= 224) mods = mods or (1 shl (usage - 224))
            else { keys.remove(usage); keys.add(usage) }
            push()
            return
        }
        if (usage < 224 && !hold) return   // yazı modunda bırakma bilgisi gerekmez
        // Çok kısa basışlar kaybolmasın: en az MIN_HOLD ms basılı kalsın
        val wait = MIN_HOLD - (now - (downAt[usage] ?: 0L))
        if (wait > 0) {
            val r = Runnable { pend.remove(usage); release(usage) }
            pend[usage] = r
            q.postDelayed(r, wait)
        } else release(usage)
    }

    private fun release(usage: Int) {
        downAt.remove(usage)
        if (usage >= 224) mods = mods and (1 shl (usage - 224)).inv()
        else keys.remove(usage)
        push()
        q.postDelayed({ push() }, 30)   // bırakma raporu kaybolursa tuş takılı kalmasın
    }

    private fun tap(usage: Int) {
        keys.remove(usage); keys.add(usage); push()
        q.postDelayed({ keys.remove(usage); push() }, 35)
        q.postDelayed({ push() }, 65)
    }

    private fun push() {
        val h = host ?: return
        val r = ByteArray(8)
        r[0] = mods.toByte()
        for (i in 0 until minOf(6, keys.size)) r[2 + i] = keys[i].toByte()
        hid?.sendReport(h, 1, r)
    }

    companion object {
        private const val MIN_HOLD = 40L
        private val DESC: ByteArray = intArrayOf(
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
            0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
            0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
            0xC0
        ).map { it.toByte() }.toByteArray()
    }
}
